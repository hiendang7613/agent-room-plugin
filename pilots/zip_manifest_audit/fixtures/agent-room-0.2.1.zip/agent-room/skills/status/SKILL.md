---
name: status
description: Summarize room members, open work, native requests and unaccounted prompts.
disable-model-invocation: true
---

Read `agent-room --json status`. Reject arguments. Give a concise Vietnamese summary of
current mode, actual supervisor liveness, member errors, unfinished tasks/next steps,
questions and approvals waiting for admin. A saved running state with no live supervisor
is stale, not healthy. Native turn completion is not task completion. Do not start workers,
repair configuration or make provider calls as part of status.

Use task.review_status, latest_attempt, missing_evidence, last_progress and unprocessed_messages
to identify stale reviews and incomplete work. A completed native attempt or processed ACK
does not mean acceptance passed. Missing native output/turn IDs remain unknown. When recovery
matters, read `agent-room task context TASK_ID` and report its checkpoint_reconcile reasons.
