# Agent Room — local distribution

Native Claude Code/Codex coordination. Default: CLAUDE_01 + CODEX_EXPERT.
Full: CLAUDE_01, CODEX_01, CLAUDE_EXPERT, CODEX_EXPERT.

Requires macOS, Python 3.11+, Claude Code background sessions and Codex app-server.
Sign in through the native CLIs. Extract this archive to a stable directory.

In Claude Code:

```text
/plugin marketplace add /absolute/path/to/extracted/agent-room
/plugin install agent-room@agent-room-marketplace
```

Reopen Claude Code in the target project, then run `/init-agents-space` or
`/init-agents-space --mode full`. The namespaced `/agent-room:init-agents-space`
works when another personal command owns the bare alias. Existing project
instructions are preserved; existing manual agents_space folders are not migrated.

Use `/agent-room:status`, `/agent-room:stop`, `/agent-room:start`, `/agent-room:doctor`.
Main exit stops the workers; manual stop persists. Doctor checks CLI capabilities,
not real model behavior. Native permissions remain with each harness.

For a schema-1 room, stop it with the previous compatible plugin first. Close its
old controllers, update the plugin and run `bin/agent-room --project PROJECT migrate`.
The migration saves an SQLite backup and changes no credentials/native permissions.
See [V1.1 contracts and operations](docs/v1.1.md) for review/checkpoint commands and recovery.

`PACKAGE-MANIFEST.json` binds the shipped files. Reference repositories, tests,
project runtime, personal logs and source research reports are excluded.
This local artifact is not evidence of publication or live-model acceptance.
