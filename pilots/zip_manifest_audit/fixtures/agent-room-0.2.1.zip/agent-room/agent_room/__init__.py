"""Native Claude Code / Codex room coordination. No model execution loop."""

__version__ = "0.2.1"
