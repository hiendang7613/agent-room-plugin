# Agent Room — local distribution

Native Claude Code/Codex coordination. Default: CLAUDE_01 + CODEX_EXPERT.
Full: CLAUDE_01, CODEX_01, CLAUDE_EXPERT, CODEX_EXPERT.

Version 0.3.1 uses on-demand convention guides and `inbox --pending` for messages without
a processing ACK. Start each fresh inbox sweep at `--after 0` and follow all `next_after` pages.
Failed/unknown delivery remains visible and needs reconciliation before retry. Full `inbox`
history remains available. Startup still reads the working agreement and refreshes current state.

Version 0.3.0 added shared advisory knowledge with sources, revisions and retirement, plus
compact per-message task summaries. Agents can converse freely and learn during useful work.
Use `agent-room knowledge --help` and `agents_space/conventions/learning.md`. Inferred preferences
stay tentative; main needs an original admin receipt for admin-stated records. Memory grants
no task authority or permission. This uses native harnesses, with no new model loop or scheduler.

Requires macOS, Python 3.11+, Claude Code background sessions and Codex app-server.
Sign in through the native CLIs. Extract this archive to a stable directory.

In Claude Code:

```text
/plugin marketplace add /absolute/path/to/extracted/agent-room
/plugin install agent-room@agent-room-marketplace
```

Reopen Claude Code in the target project, then run `/init-agents-space` or
`/init-agents-space --mode full`. The namespaced `/agent-room:init-agents-space`
works when another personal command owns the bare alias. Existing project
instructions are preserved; existing manual agents_space folders are not migrated.

Use `/agent-room:status`, `/agent-room:stop`, `/agent-room:start`, `/agent-room:doctor`.
Main exit stops the workers; manual stop persists. Doctor checks CLI capabilities,
not real model behavior. Native permissions remain with each harness.

For a schema-1 or schema-2 room, stop it with the previous compatible plugin and close its
old controllers before updating. From the extracted 0.3.1 directory run:

```sh
bin/agent-room --project PROJECT migrate
bin/agent-room --project PROJECT init --no-start
```

Migration saves an SQLite backup before upgrading to schema 3. Schema-2 task/review/checkpoint
and native identities are preserved. Init adds the learning guide while preserving custom room
files. Reopen/start only after these steps; use one plugin version per room. Existing proposal
bindings remain until explicitly resolved. See [contracts and operations](docs/v1.1.md).

From 0.3.0, schema 3 stays unchanged: stop the room, update the plugin, run `init --no-start`,
then reopen/start. Re-init updates the managed AGENTS/CLAUDE blocks and preserves every existing
room guide, including its README. Review the existing startup checklist yourself if it still
requires reading all guides each time; the new on-demand checklist is scaffolded in new rooms.
Native session context can retain earlier instructions. This patch does not erase native memory.

`PACKAGE-MANIFEST.json` binds the shipped files. Reference repositories, tests,
project runtime, personal logs and source research reports are excluded.
This local artifact is not evidence of publication or live-model acceptance.
