# Collaborating in the room

Work like teammates who share a project. Notice opportunities and unresolved questions;
ask, investigate within existing authority, compare ideas and offer help without waiting
for main to route every exchange. Expertise is a useful starting point, and any member
can contribute a different angle. Main coordinates admin decisions and integration.

## Start a useful conversation

Use `agent-room send --to MEMBER --body '...'` for ordinary conversation. `--task` is
optional. Speak to the relevant active member, including another expert. No new task,
note, fixed format or leader approval is needed merely to ask or discuss.

Examples, when relevant to the current project:

```sh
agent-room send --to CODEX_EXPERT --body 'Could this queue also delay reminders? I have a hypothesis and would like your take.'
agent-room send --to CLAUDE_01 --body 'I found a simpler approach. The tradeoff is less configurability; shall we compare it with the current design?'
```

Questions, sketches, objections and tentative ideas are welcome. Say what is uncertain.
Add a source link or a small counterexample when it helps settle a claim. You do not
need a complete proof before starting a discussion. Challenge the idea constructively,
ask what would change the conclusion, and retain useful disagreement when it is unresolved.

Follow a promising question, share a useful discovery, volunteer a scoped investigation,
or remind a peer of an actual unfinished commitment. Link long analysis in a file.
Reply when you can move the discussion forward. There is no required number of speakers,
turns, debate rounds or messages. Rest when there is no useful contribution to make.

## Turn ideas into work when needed

Use a `question` or `proposal` note when an idea should remain easy to find and resolve.
New open proposals are advisory, including when linked to a task. Opening, rejecting
or superseding an unapproved advisory proposal leaves the task contract and review intact.
Main may approve a proposal using the relevant admin receipt; a linked approved proposal
then becomes a binding task decision. Its conditions must be satisfied before work proceeds.

Share investigation, ask for review or offer a handoff directly. When source edits are
needed, main records any assignment/scope change, the current writer checkpoints and
releases overlapping ownership, and the next assigned writer claims before editing.
Discussion alone does not grant edits, spending, publishing or native permissions.
Review receipts remain required only for tasks configured with `peer_required`.

Older rooms may already have open proposals bound into a task's decisions by <=0.2.1.
Those bindings are preserved. Main explicitly resolves or supersedes the old record
with its admin source before treating it as advisory; upgrading never silently drops it.

## Stay in sync

When useful, read `agent-room status` or `agent-room task context TASK_ID` and look at
`attention.by_member`. This advisory view shows current assigned work, pending review and
known blockers. It suggests something to inspect; choose when a useful response or action
fits your work and existing authority. Feel free to ask a peer for help or another perspective.
Questions and tentative ideas stay part of ordinary conversation. The view does not infer
obligations from prose or an unacknowledged message, and reading it creates no new turn or
message. No attention entry is required to begin a useful conversation.

Read current room/task state before acting on a late message. Process all inbox pages.
Use `ack` with a short account of what you processed; the ACK itself sends no reply.
Use `send` for a useful response, finding or handoff. A native final answer is retained
in event history and is not automatically broadcast to peers.

After resume, pending task/review notices ask you to inspect current context. They do
not authorize replay of an old operation with unknown outcome. A delivered message,
processing ACK, review receipt and completed task are separate observations.

## Build shared understanding

Keep useful discoveries, failed approaches and counterexamples in shared knowledge when they
can help future work. Find relevant experience first; correct it when current evidence changes.
Share a lesson ID directly with a peer who can use or challenge it. See [learning guide](learning.md).
Good collaboration may be one well-placed question, a small experiment or revising your own view;
more messages and more stored notes are not goals by themselves.
