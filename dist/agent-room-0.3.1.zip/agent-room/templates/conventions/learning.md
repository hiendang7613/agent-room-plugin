# Learning together

Use the room's shared knowledge when experience can help the next decision. Any member can
remember a useful discovery, failed approach, counterexample or tentative preference during
ordinary work. Choose what deserves keeping; routine steps and transcripts usually do not.
There is no compulsory retrospective, minimum number of lessons, or periodic learning turn.

## Find before remembering

```sh
agent-room --json knowledge search 'queue retry'
agent-room --json knowledge show K-ID
```

Search uses all whitespace-separated terms as literal, case-insensitive substrings across
title, body, tags, evidence, applicability and limits. Use a few concrete terms, not a whole
prompt. Broaden or change terms if relevant experience is missing. This is local text search,
not semantic retrieval. Results contain small previews and read commands; follow `next_after`
with `--after` to read further pages. Nothing matching means no matching recorded knowledge.

Read a relevant record and its evidence before relying on it. Check `applies_when`, `limits`
and current source. The record's `basis` describes where the claim came from; no label proves
that it is correct. An experiment is evidence for its conditions, not a universal rule.

## Save what changed your understanding

Write a JSON file, then use `agent-room knowledge add --input FILE.json`:

```json
{
  "title": "Check the receiver before retrying a message",
  "body": "In the bounded restart experiment, dispatch succeeded while the final native completion was missing. Reconcile the receiver before resending.",
  "basis": "observed",
  "evidence": ["docs/restart-experiment.json: exact run and message IDs"],
  "tags": ["restart", "messaging"],
  "applies_when": "A native dispatch has an unknown outcome",
  "limits": "One local experiment; does not establish transport guarantees"
}
```

Use real evidence, not the example path. `title`, `body` and at least one `evidence` entry are
required. Tags, applicability and limits are free text; there is no fixed domain taxonomy.
Default `basis=inferred` keeps a proposed explanation tentative. `observed` records a member's
reported observation. The CLI checks structure, not whether the cited experiment really ran.

The committed record is immediately available to every member in this project. Share its ID
with relevant peers using `send` when it helps their work; saving does not broadcast or wake
everyone. Peers can challenge a lesson and contribute counterevidence without asking main
to relay the conversation. Search only when useful; do not load the whole memory each turn.

## Understand admin style without inventing instructions

Any member may infer a tentative preference, tagged for example `admin-style`, with the actual
observations and uncertainty in the record. Main can record a preference explicitly stated by
admin using `basis=admin` and `source=P-ID`, the original admin receipt. Keep the original scope,
conditions and exceptions. This label means main supplied a real receipt, not that software
verified the interpretation. Never turn repeated agent guesses into an admin statement.

Current requests and original decisions take precedence over remembered preferences. Memory
cannot authorize edits, provider spending, permission changes or shipping. Material uncertainty
about intent goes to main; routine reversible choices can use judgment within existing authority.

## Refine, correct and try again

When evidence improves, update the existing record with a small JSON patch:

```sh
agent-room knowledge update K-ID --expected-version 1 --input correction.json
agent-room knowledge history K-ID
```

All members may revise ordinary records; main maintains admin-stated ones. Concurrent edits
require rereading and reconciling the current version. The author, latest editor and previous
revisions remain visible. Add disagreements and limits while evidence is unresolved.

Use `{"state":"retired","limits":"Why this no longer applies"}` to retire a lesson. Default
search excludes it immediately. `show`, `history` and `search --include-retired` still expose
it explicitly; retirement is not deletion of sensitive data. Do not store secrets or unrelated
personal information. Main can retire an inaccurate admin-stated record and replace it with
an inference; peers can raise counterevidence directly.

For self-improvement, let an actual friction point lead to a small authorized experiment.
Compare against the previous behavior, retain useful evidence, and revise or retire the lesson
if the result disagrees. Use the existing task and review controls when code changes require
them. Stop when there is no worthwhile next experiment within scope. This is an opportunity
for agents to improve their practice, not a scheduler, mandatory stage or unbounded model loop.
