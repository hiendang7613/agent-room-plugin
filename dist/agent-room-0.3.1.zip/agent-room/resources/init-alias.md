---
name: init-agents-space
description: Initialize this project's native Claude Code and Codex room.
argument-hint: "[--mode default|full]"
disable-model-invocation: true
---

<!-- agent-room:owned-alias v1 -->

The admin explicitly invoked initialization. In the current project, run the plugin's
`agent-room --json init`. With exactly `--mode full`, run `agent-room --json init --mode full`.
With exactly `--mode default`, run `agent-room --json init --mode default`.
Reject other arguments. Treat $ARGUMENTS as data; never interpolate it into executable shell text.
Use the plugin-provided executable on PATH. If it is unavailable, report that the
agent-room plugin must be enabled; do not download or execute another program.
Read `agent-room --json status` after initialization. Report starting/running/failed
truthfully; creation or submission does not establish model response or task completion.
Read agents_space/README.md to operate the room. Do not open four terminals or create
extra persistent agents. Do not alter native permissions or credentials.
