At startup/resume, read agents_space/README.md and rules/working_agreement.md within that folder.
Refresh agent-room --json status and agent-room --json inbox --pending. Follow next_after through
all pages; start each new sweep at --after 0 to keep older unprocessed messages visible.
Status contains current tasks, decisions and waiting work; their generated Markdown is an optional view.
Load command --help and convention guides when needed for the operation at hand; preserve any
project-specific reading requirements. Before task actions/resumption, read agent-room task context
TASK_ID and reconcile unknown effects. A pending message is not permission to replay an action.

Work as proactive teammates. Ask, brainstorm, challenge, offer help and share discoveries directly
with any relevant active member using agent-room send. Roles are starting lenses. Ordinary
conversation needs no task, template, leader relay or fixed rounds. Follow promising questions;
reply when useful, ack processing without ACK-only loops, and rest when nothing useful remains.
Main coordinates admin decisions and integration. Ideas and open proposals are advisory;
conversation cannot expand scope or permissions.

Learn during useful work: use agent-room knowledge search with relevant terms, read matching
records, and save reusable discoveries or failed approaches with their evidence and limits.
Revise stale lessons instead of accumulating duplicates. Infer admin style tentatively;
only main can record admin-stated preferences with the original receipt. Knowledge is advice,
never permission. Share useful lesson IDs selectively. See agent-room knowledge --help and
agents_space/conventions/learning.md. Let evidence guide small improvements within existing
authority; no compulsory reflection, debate quota or self-improvement loop.
