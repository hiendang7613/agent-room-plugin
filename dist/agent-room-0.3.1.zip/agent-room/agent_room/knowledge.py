"""Project-local, advisory learning. Native agents decide what is useful to remember."""

import json

from agent_room.common import MEMBERS, RoomError, dumps, now, uid
from agent_room.evidence import bounded


FIELDS = {"title", "body", "basis", "evidence", "tags", "applies_when", "limits", "source", "state"}
RULE = "Advisory project knowledge, not task authority or permission. Inferences remain tentative; verify applicability and sources."


def validate(record):
    for key, limit in (("title", 160), ("body", 4000), ("applies_when", 1000), ("limits", 1000),
                       ("source", 200), ("basis", 20), ("state", 20)):
        value = record.get(key, "")
        if not isinstance(value, str) or len(value) > limit or (key in {"title", "body"} and not value.strip()):
            raise RoomError(f"{key} must be {'nonempty ' if key in {'title', 'body'} else ''}text, at most {limit} characters")
    for key, count, size in (("evidence", 12, 1000), ("tags", 12, 64)):
        values = record.get(key, [])
        if (not isinstance(values, list) or len(values) > count or (key == "evidence" and not values)
                or any(not isinstance(value, str) or not value.strip() or len(value) > size for value in values)):
            raise RoomError(f"{key} must contain {'1..' if key == 'evidence' else '0..'}{count} nonempty strings, at most {size} characters each")
    if record.get("basis") not in {"inferred", "observed", "admin"}:
        raise RoomError("basis must be inferred, observed or admin; it describes provenance, not verification")
    if record.get("state") not in {"active", "retired"}:
        raise RoomError("state must be active or retired")
    if record.get("source") and record["basis"] != "admin":
        raise RoomError("source is the original admin receipt for basis=admin; put other sources in evidence")


class Knowledge:
    def __init__(self, store):
        self.store = store

    def write(self, actor, data, record_id=None, expected=None):
        if actor not in MEMBERS:
            raise RoomError("Unknown member", "identity")
        if not isinstance(data, dict) or data.keys() - FIELDS or not data:
            raise RoomError("Use knowledge fields: " + ", ".join(sorted(FIELDS)))
        with self.store.tx() as db:
            previous = self.store.record(db, "knowledge", record_id) if record_id else None
            record = dict(previous or {"basis": "inferred", "state": "active", "tags": [],
                                      "applies_when": "", "limits": "", "source": ""})
            record.update(data)
            validate(record)
            if record["basis"] == "admin" or (previous and previous["basis"] == "admin"):
                self.store.main_only(actor)
                self.store.source(db, record.get("source"))
            record["editor"] = actor
            if previous:
                self.store.save(db, "knowledge", record, expected)
            else:
                record.update(id=uid("K-"), version=1, author=actor, created=now(), updated=now())
                db.execute("INSERT INTO knowledge VALUES (?,?,?)", (record["id"], 1, dumps(record)))
            # History and current revision commit together. Never enqueue a conversation
            # merely because a memory changed; peers choose what is useful to share.
            self.store.event(db, "knowledge.revised", record)
            return dict(record, rule=RULE)

    def show(self, record_id):
        with self.store.read() as db:
            return dict(self.store.record(db, "knowledge", record_id), rule=RULE)

    def search(self, query="", after=0, limit=8, include_retired=False):
        self.page(after, limit)
        if not isinstance(query, str) or len(query) > 200:
            raise RoomError("Search query must be text, at most 200 characters")
        terms = query.casefold().split()
        items = []
        with self.store.read() as db:
            for row in db.execute("SELECT rowid AS cursor,data FROM knowledge WHERE rowid>? ORDER BY rowid", (after,)):
                record = json.loads(row["data"])
                if record["state"] == "retired" and not include_retired:
                    continue
                haystack = " ".join([record[key] for key in ("title", "body", "applies_when", "limits")]
                                    + record["tags"] + record["evidence"]).casefold()
                if not all(term in haystack for term in terms):
                    continue
                items.append(dict({key: record[key] for key in ("id", "version", "title", "basis", "state", "tags")},
                                  preview=bounded(record["body"], 280), applies_when=bounded(record["applies_when"], 160),
                                  limits=bounded(record["limits"], 160), cursor=row["cursor"],
                                  read_command=f"agent-room knowledge show {record['id']}"))
                if len(items) > limit:
                    break
        return {"items": items[:limit], "next_after": items[limit - 1]["cursor"] if len(items) > limit else None,
                "rule": RULE, "matching": "All whitespace-separated terms, literal case-insensitive substring; active records by default."}

    def history(self, record_id, after=0, limit=8):
        self.page(after, limit)
        with self.store.read() as db:
            current = self.store.record(db, "knowledge", record_id)
            rows = []
            for row in db.execute("SELECT seq,data FROM events WHERE kind='knowledge.revised' AND seq>? ORDER BY seq", (after,)):
                if json.loads(row["data"])["id"] == record_id:
                    rows.append(row)
                if len(rows) > limit:
                    break
        return {"current_version": current["version"], "current_state": current["state"], "historical": True,
                "items": [dict(json.loads(row["data"]), cursor=row["seq"]) for row in rows[:limit]],
                "next_after": rows[limit - 1]["seq"] if len(rows) > limit else None, "rule": RULE}

    @staticmethod
    def page(after, limit):
        if after < 0 or not 1 <= limit <= 50:
            raise RoomError("Use after >= 0 and limit 1..50")
