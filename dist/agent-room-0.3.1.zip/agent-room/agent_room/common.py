"""Shared local file and process primitives."""

from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import uuid


PLUGIN_ROOT = Path(__file__).resolve().parent.parent
MODES = {
    "default": ("CLAUDE_01", "CODEX_EXPERT"),
    "full": ("CLAUDE_01", "CODEX_01", "CLAUDE_EXPERT", "CODEX_EXPERT"),
}
MEMBERS = MODES["full"]


class RoomError(Exception):
    def __init__(self, message, code="invalid", **details):
        super().__init__(message)
        self.code = code
        self.details = details


def native_event_prompt(body):
    """Known native event envelopes also reach Claude's UserPromptSubmit hook."""
    return body.lstrip().startswith(("[Agent Room peer event ", "<task-notification>"))


def now():
    return datetime.now(timezone.utc).isoformat()


def uid(prefix=""):
    return prefix + str(uuid.uuid4())


def dumps(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def atomic_write(path, content, mode=0o600):
    path = Path(path)
    if path.is_symlink():
        raise RoomError(f"Refusing symlink: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix="." + path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            os.fchmod(stream.fileno(), mode)
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@contextmanager
def file_lock(path, blocking=True):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        except BlockingIOError as exc:
            raise RoomError("Another room operation owns the lock", "conflict") from exc
        yield
    finally:
        os.close(fd)


def process_stamp(pid):
    if not isinstance(pid, int) or pid < 2:
        return None
    result = subprocess.run(["ps", "-p", str(pid), "-o", "stat=", "-o", "lstart="],
                            capture_output=True, text=True, timeout=3)
    if result.returncode and result.stderr.strip():
        raise RoomError("Process inspection is unavailable in this environment", "process_inspection")
    fields = result.stdout.strip().split(None, 1)
    return fields[1] if len(fields) == 2 and not fields[0].startswith("Z") else None


def process_alive(pid, stamp):
    return bool(stamp and process_stamp(pid) == stamp)


def scoped_path(project, value):
    root = Path(project).resolve()
    path = Path(value)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise RoomError("Scope must be a relative project path")
    resolved = (root / path).resolve()
    if not resolved.is_relative_to(root) or resolved == root:
        raise RoomError("Scope escapes the project or claims the entire project")
    if resolved.is_relative_to(root / "agents_space" / ".runtime"):
        raise RoomError("Runtime files cannot be a source-edit scope")
    return resolved.relative_to(root).as_posix()


def overlaps(left, right):
    return left == right or left.startswith(right + "/") or right.startswith(left + "/")


def fingerprint(project, paths):
    result = {}
    for value in paths:
        relative = scoped_path(project, value)
        path = Path(project) / relative
        if path.is_dir():
            raise RoomError("A source snapshot requires individual files")
        result[relative] = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
    return result
