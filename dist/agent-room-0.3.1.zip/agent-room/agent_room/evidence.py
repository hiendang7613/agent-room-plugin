"""Source identities and bounded context, independent of native model execution."""

import hashlib
from pathlib import Path

from agent_room.common import RoomError, dumps, scoped_path


def digest(value):
    return hashlib.sha256(dumps(value).encode()).hexdigest()


def capture(project, paths):
    if not isinstance(paths, list) or not 1 <= len(paths) <= 256 or any(not isinstance(p, str) or not p for p in paths):
        raise RoomError("paths must contain 1..256 individual project files")
    snapshot = {}
    for value in paths:
        relative = scoped_path(project, value)
        current = Path(project)
        for part in Path(value).parts:
            current /= part
            if current.is_symlink():
                raise RoomError("Review/checkpoint paths must not contain symlinks", "conflict")
        path = Path(project) / relative
        if not path.exists():
            snapshot[relative] = None  # An explicit deletion/absence is part of the scope.
        elif not path.is_file():
            raise RoomError("Review/checkpoint paths must be individual regular files")
        else:
            hashed = hashlib.sha256()
            with path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    hashed.update(chunk)
            snapshot[relative] = hashed.hexdigest()
    return snapshot


def source_matches(project, snapshot):
    try:
        return capture(project, list(snapshot)) == snapshot
    except (OSError, RoomError):
        return False


def nonempty_strings(value, label, maximum=100):
    if not isinstance(value, list) or not 1 <= len(value) <= maximum or any(not isinstance(x, str) or not x.strip() or len(x) > 4000 for x in value):
        raise RoomError(f"{label} requires 1..{maximum} nonempty strings of at most 4000 characters")


def bounded(value, limit=1200):
    """A preview is explicitly truncated; the complete record stays in SQLite."""
    if isinstance(value, str):
        return value if len(value) <= limit else value[:limit] + " [truncated; read full record]"
    if isinstance(value, list):
        result = [bounded(item, limit) for item in value[:12]]
        if len(value) > 12:
            result.append(f"[{len(value) - 12} more; read full record]")
        return result
    if isinstance(value, dict):
        return {key: bounded(item, limit) for key, item in value.items()}
    return value
