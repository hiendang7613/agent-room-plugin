"""Human commands and bounded model-facing operations for a single project room."""

import argparse
import asyncio
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

from agent_room import __version__
from agent_room.common import MEMBERS, MODES, RoomError, dumps, fingerprint, process_alive
from agent_room.hooks import handle
from agent_room.knowledge import Knowledge
from agent_room.native import doctor
from agent_room.runtime import Supervisor, approval_response, request_stop, start_room
from agent_room.scaffold import initialize, install_alias
from agent_room.schema import migrate
from agent_room.store import Store


class RoomParser(argparse.ArgumentParser):
    def error(self, message):
        print(dumps({"ok": False, "error": {"code": "arguments", "message": message}}))
        raise SystemExit(2)


def positive_timeout(value):
    timeout = float(value)
    if not 0 < timeout < float("inf"):
        raise argparse.ArgumentTypeError("timeout must be positive and finite")
    return timeout


def parser():
    root = RoomParser(description="Coordinate native Claude Code/Codex sessions. No provider calls in help/doctor/status.")
    root.add_argument("--version", action="version", version=__version__)
    root.add_argument("--project", default=os.environ.get("AGENT_ROOM_PROJECT", os.getcwd()))
    root.add_argument("--json", action="store_true", help="Machine-readable result without progress text")
    commands = root.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init", help="Preserve project instructions, initialize a room, then start native workers")
    init.add_argument("--mode", choices=MODES)
    init.add_argument("--no-start", action="store_true", help="Prepare project files only; no native sessions")
    start = commands.add_parser("start", help="Start/resume the exact native workers")
    start.add_argument("--mode", choices=MODES)
    commands.add_parser("status", help="Read current state and advisory attention by member; no work is started")
    commands.add_parser("doctor", help="Read-only CLI capability checks; no provider probe or automatic repair")
    commands.add_parser("migrate", help="Upgrade a stopped schema-1/2 room, preserving a pre-upgrade SQLite backup")
    stop = commands.add_parser("stop", help="Persist manual stop; wait for owned worker shutdown")
    stop.add_argument("--timeout", type=positive_timeout, default=20)
    commands.add_parser("hook", help=argparse.SUPPRESS)
    commands.add_parser("install-alias", help="Install the bare personal init slash command; never overwrite another skill")
    serve = commands.add_parser("_serve", help=argparse.SUPPRESS)
    serve.add_argument("--generation", required=True)
    tasks = commands.add_parser("task", help="Assigned work, checkpoints, evidence and writer claims").add_subparsers(dest="action", required=True)
    for action in ("create", "update", "submit", "checkpoint"):
        sub = tasks.add_parser(action)
        sub.add_argument("--input", default="-", help="JSON file or - for stdin")
        if action != "create":
            sub.add_argument("id")
            sub.add_argument("--expected-version", type=int, required=True)
    listing = tasks.add_parser("list")
    listing.add_argument("--all", action="store_true")
    listing.add_argument("--owner", choices=MEMBERS)
    show = tasks.add_parser("show")
    show.add_argument("id")
    task_context = tasks.add_parser("context", help="Read bounded current context, advisory attention and reconciliation evidence")
    task_context.add_argument("id")
    claim = tasks.add_parser("claim")
    claim.add_argument("id")
    claim.add_argument("--expected-version", type=int, required=True)
    release = tasks.add_parser("release")
    release.add_argument("id")
    release.add_argument("--token", required=True)
    for noun in ("submission", "review", "checkpoint"):
        operations = commands.add_parser(noun, help="Read immutable evidence records" if noun != "review" else "Record an assigned peer's source-bound review").add_subparsers(dest="action", required=True)
        show_record = operations.add_parser("show")
        show_record.add_argument("id")
        if noun == "review":
            record = operations.add_parser("record")
            record.add_argument("id", help="Submission ID to review")
            record.add_argument("--input", default="-")
    attempts = commands.add_parser("attempt", help="Native dispatch and output evidence, separate from task completion").add_subparsers(dest="action", required=True)
    attempts_list = attempts.add_parser("list")
    attempts_list.add_argument("--task")
    attempts_list.add_argument("--after", type=int, default=0)
    attempts_list.add_argument("--limit", type=int, default=50)
    attempts_show = attempts.add_parser("show")
    attempts_show.add_argument("id")
    notes = commands.add_parser("note", help="Questions, proposals and admin decisions with source provenance").add_subparsers(dest="action", required=True)
    for action in ("add", "resolve"):
        sub = notes.add_parser(action)
        sub.add_argument("--input", default="-")
        if action == "resolve":
            sub.add_argument("id")
            sub.add_argument("--expected-version", type=int, required=True)
    notes.add_parser("list")
    show = notes.add_parser("show")
    show.add_argument("id")
    knowledge = commands.add_parser("knowledge", help="Shared advisory lessons, experiences and tentative preferences").add_subparsers(dest="action", required=True)
    for action in ("add", "update"):
        sub = knowledge.add_parser(action)
        sub.add_argument("--input", default="-")
        if action == "update":
            sub.add_argument("id")
            sub.add_argument("--expected-version", type=int, required=True)
    knowledge.add_parser("show").add_argument("id")
    for action in ("search", "history"):
        sub = knowledge.add_parser(action)
        if action == "search":
            sub.add_argument("query", nargs="?", default="")
            sub.add_argument("--include-retired", action="store_true")
        else:
            sub.add_argument("id")
        sub.add_argument("--after", type=int, default=0)
        sub.add_argument("--limit", type=int, default=8)
    send = commands.add_parser("send", help="Queue a peer message. Success means saved, not read or completed")
    send.add_argument("--to", choices=MEMBERS, required=True)
    body = send.add_mutually_exclusive_group()
    body.add_argument("--body-file", default="-", help="Text file or - for stdin; treat text as data")
    body.add_argument("--body", help="Inline text argument; avoids shell heredoc temporary files in a sandbox")
    send.add_argument("--task")
    send.add_argument("--id", help="Stable message ID for a repeated submission")
    inbox = commands.add_parser("inbox", help="Read this member's paginated messages")
    inbox.add_argument("--after", type=int, default=0)
    inbox.add_argument("--limit", type=int, default=50)
    inbox.add_argument("--pending", action="store_true",
                       help="Only messages without a processing ACK, including failed/unknown delivery; start each fresh sweep at --after 0")
    ack = commands.add_parser("ack", help="Record recipient processing, without sending a reply")
    ack.add_argument("id")
    ack.add_argument("--evidence", required=True)
    retry = commands.add_parser("retry-message", help="Explicitly requeue failed/unknown dispatch after reconciliation")
    retry.add_argument("id")
    retry.add_argument("--source", required=True)
    retry.add_argument("--reconciled", required=True)
    intake = commands.add_parser("intake", help="Original admin receipts; semantic classification belongs to CLAUDE_01").add_subparsers(dest="action", required=True)
    intake.add_parser("list")
    recover = intake.add_parser("recover", help="Main-only recovery of original human text after a failed intake hook")
    recover.add_argument("--body-file", default="-")
    recover.add_argument("--source-ref", required=True, help="Reference to the original human message/transcript; never peer text")
    account = intake.add_parser("account")
    account.add_argument("id")
    account.add_argument("--disposition", required=True)
    account.add_argument("--refs", nargs="*", default=[])
    approvals = commands.add_parser("approval", help="Native requests, not room/task authorization").add_subparsers(dest="action", required=True)
    approvals.add_parser("list")
    respond = approvals.add_parser("respond")
    respond.add_argument("id")
    respond.add_argument("--source", required=True, help="Receipt of the explicit human answer to THIS request")
    respond.add_argument("--decision", choices=("accept", "decline", "cancel"), required=True)
    snapshot = commands.add_parser("snapshot", help="Hash exact source files for a review/checkpoint")
    snapshot.add_argument("paths", nargs="+")
    history = commands.add_parser("history", help="Paginated durable messages/events/admin prompt history")
    history.add_argument("--kind", choices=("messages", "events", "prompts"), default="messages")
    history.add_argument("--after", type=int, default=0)
    history.add_argument("--limit", type=int, default=50)
    return root


def read_input(path, structured=False):
    content = sys.stdin.read() if path == "-" else Path(path).read_text()
    if structured:
        data = json.loads(content)
        if not isinstance(data, dict):
            raise RoomError("JSON input must be an object")
        return data
    return content


def run(args):
    command = args.command
    if command == "hook":
        return handle(json.load(sys.stdin))
    if command == "doctor":
        return doctor()
    if command == "install-alias":
        return {"installed": install_alias()}
    store = Store(args.project)
    if command == "migrate":
        if os.environ.get("AGENT_ROOM_MEMBER", "CLAUDE_01") != "CLAUDE_01":
            raise RoomError("Only the main/operator may migrate an offline room", "authority")
        return migrate(store)
    if command == "init":
        if os.environ.get("AGENT_ROOM_MEMBER", "CLAUDE_01") != "CLAUDE_01":
            raise RoomError("Only the admin's main session can initialize a room", "authority")
        if not args.no_start:
            checks = doctor()
            if not checks["ok"]:
                raise RoomError("Dependencies are missing. No project files changed.", "dependency", checks=checks)
            if not os.environ.get("AGENT_ROOM_SESSION_ID"):
                raise RoomError("Run /init-agents-space in Claude Code, or use init --no-start for files only", "identity")
        room = initialize(args.project, args.mode)
        if args.no_start:
            return {"initialized": True, "started": False, "room": room}
        return start_room(store, os.environ.get("AGENT_ROOM_SESSION_ID"),
                          permission_mode=os.environ.get("AGENT_ROOM_PERMISSION_MODE", "default"))
    if command == "_serve":
        asyncio.run(Supervisor(store, args.generation).run())
        room = store.room()
        if room["status"] == "failed":
            raise RoomError("Supervisor failed", "native", detail=room["error"])
        return {"stopped": room["status"] == "stopped"}
    if command == "start":
        return start_room(store, os.environ.get("AGENT_ROOM_SESSION_ID"), args.mode,
                          os.environ.get("AGENT_ROOM_PERMISSION_MODE", "default"))
    if command == "status":
        status = store.status()
        def observed_alive(pid, stamp):
            try:
                return process_alive(pid, stamp)
            except (OSError, subprocess.TimeoutExpired, RoomError):
                status["process_inspection"] = "unavailable; process_alive=null is unknown, not stopped. Room data remains readable; no escalation is needed for status."
                return None
        supervisor = status["room"].get("supervisor") or {}
        status["supervisor_alive"] = observed_alive(supervisor.get("pid"), supervisor.get("stamp"))
        for member in status["members"]:
            member.pop("token_hash", None)
            member["process_alive"] = observed_alive(member.get("pid"), member.get("stamp"))
        return status
    if command == "snapshot":
        return fingerprint(store.project, args.paths)
    if command in {"submission", "review", "checkpoint", "attempt"} and args.action == "show":
        table = {"submission": "submissions", "review": "reviews", "checkpoint": "checkpoints", "attempt": "attempts"}[command]
        with store.read() as db:
            result = store.entry(db, table, args.id)
            if command == "submission":
                result["review_receipts"] = [row[0] for row in db.execute("SELECT id FROM reviews WHERE submission=? ORDER BY rowid", (args.id,))]
            return result
    if command == "attempt":
        return store.attempts(args.task, args.after, args.limit)
    if command == "task" and args.action == "context":
        return store.task_context(args.id)
    if command == "history":
        if not 1 <= args.limit <= 200 or args.after < 0:
            raise RoomError("Use limit 1..200 and after >= 0")
        with store.read() as db:
            rows = [dict(r) for r in db.execute(f"SELECT rowid AS cursor,* FROM {args.kind} WHERE rowid>? ORDER BY rowid LIMIT ?", (args.after, args.limit + 1))]
        return {"items": rows[:args.limit], "next_after": rows[args.limit-1]["cursor"] if len(rows) > args.limit else None}
    if command == "task" and args.action in {"list", "show"}:
        if args.action == "show":
            with store.read() as db:
                return store.record(db, "tasks", args.id)
        return [t for t in store.status()["tasks"] if (args.all or t["state"] not in {"done", "cancelled"}) and (not args.owner or t["owner"] == args.owner)]
    if command == "note" and args.action in {"list", "show"}:
        if args.action == "show":
            with store.read() as db:
                return store.record(db, "notes", args.id)
        return store.status()["notes"]
    if command == "approval" and args.action == "list":
        return store.status()["approvals"]
    if command == "intake" and args.action == "list":
        return store.status()["unaccounted_prompts"]
    if command == "knowledge":
        knowledge = Knowledge(store)
        if args.action == "search":
            return knowledge.search(args.query, args.after, args.limit, args.include_retired)
        if args.action == "history":
            return knowledge.history(args.id, args.after, args.limit)
        if args.action == "show":
            return knowledge.show(args.id)
        return knowledge.write(store.actor(), read_input(args.input, True),
                               getattr(args, "id", None), getattr(args, "expected_version", None))
    actor = store.actor()
    if command == "review":
        return store.record_review(actor, args.id, read_input(args.input, True))
    if command == "stop":
        store.main_only(actor)
        request_stop(store)
        deadline = time.monotonic() + args.timeout
        while time.monotonic() < deadline:
            room = store.room()
            if room["status"] in {"stopped", "failed"}:
                if room["status"] == "failed":
                    raise RoomError("Room failed or cleanup is unconfirmed. Inspect status/logs.", "cleanup", error=room["error"])
                return {"stopped": True}
            supervisor = room.get("supervisor") or {}
            if not process_alive(supervisor.get("pid"), supervisor.get("stamp")):
                # Reconstruct cleanup ownership from persisted native IDs after coordinator failure.
                cleanup = Supervisor(store, room["generation"])
                asyncio.run(cleanup.recover_owned())
                asyncio.run(cleanup.shutdown())
                continue
            time.sleep(.2)
        raise RoomError("Stop requested; process exit not yet confirmed", "pending")
    if command == "task":
        if args.action == "create":
            return store.create_task(actor, read_input(args.input, True))
        if args.action == "update":
            return store.update_task(actor, args.id, args.expected_version, read_input(args.input, True))
        if args.action == "claim":
            return store.claim(actor, args.id, args.expected_version)
        if args.action == "submit":
            return store.submit_task(actor, args.id, args.expected_version, read_input(args.input, True))
        if args.action == "checkpoint":
            return store.checkpoint(actor, args.id, args.expected_version, read_input(args.input, True))
        return store.release(actor, args.id, args.token)
    if command == "note":
        data = read_input(args.input, True)
        if args.action == "add":
            return store.add_note(actor, data)
        return store.resolve_note(actor, args.id, args.expected_version, data)
    if command == "send":
        return store.send(actor, args.to, args.body if args.body is not None else read_input(args.body_file), args.task, args.id)
    if command == "inbox":
        return store.inbox(actor, args.after, args.limit, pending=args.pending)
    if command == "ack":
        store.acknowledge(actor, args.id, args.evidence)
        return {"processed": args.id}
    if command == "retry-message":
        store.main_only(actor)
        if not args.reconciled.strip():
            raise RoomError("Explain the outcome reconciliation first")
        with store.tx() as db:
            store.source(db, args.source)
            row = db.execute("SELECT * FROM messages WHERE id=?", (args.id,)).fetchone()
            if not row or row["status"] not in {"unknown", "failed"}:
                raise RoomError("Only failed/unknown dispatches can be explicitly retried", "conflict")
            db.execute("UPDATE messages SET status='queued', detail=? WHERE id=?", (args.reconciled, args.id))
        return {"queued": args.id, "processed": False}
    if command == "intake":
        if args.action == "recover":
            store.main_only(actor)
            body = read_input(args.body_file)
            if not body.strip() or not args.source_ref.strip():
                raise RoomError("Recovery requires original human text and its source reference")
            receipt = store.intake(os.environ["AGENT_ROOM_SESSION_ID"], body, origin="manual_recovery:" + args.source_ref)
            return {"receipt": receipt, "origin": "manual_recovery", "native_permission_approval_eligible": False}
        store.account(actor, args.id, args.disposition, args.refs)
        return {"accounted": args.id}
    if command == "approval":
        return approval_response(store, actor, args.id, args.source, args.decision)
    raise RoomError("Unsupported command")


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        result = run(args)
        if args.command == "hook":
            print(json.dumps(result, ensure_ascii=False))
            return 0
        if args.command in {"task", "note", "intake", "review", "migrate"} and getattr(args, "action", "") not in {"list", "show", "context"}:
            try:
                Store(args.project).project_views()
            except (OSError, RoomError) as exc:
                # The transaction is already committed; surface this explicitly, never suggest replay.
                print(dumps({"ok": False, "committed": True, "data": result,
                             "error": {"code": "projection", "message": str(exc)}}))
                return 1
        print(json.dumps({"ok": True, "data": result}, ensure_ascii=False,
                         indent=None if args.json else 2, separators=(",", ":") if args.json else None))
        return 1 if args.command == "doctor" and not result["ok"] else 0
    except (RoomError, OSError, ValueError, sqlite3.Error) as exc:
        error = {"code": exc.code if isinstance(exc, RoomError) else "local_error", "message": str(exc)}
        if isinstance(exc, RoomError):
            error.update(exc.details)
        if args.command == "hook":
            print(json.dumps({"systemMessage": "Agent Room hook failed: " + str(exc)}))
            return 0  # Visible diagnostic, without swallowing the user's prompt.
        print(dumps({"ok": False, "error": error}))
        return 1
