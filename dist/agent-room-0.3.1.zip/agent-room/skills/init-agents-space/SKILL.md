---
name: init-agents-space
description: Create this project's persistent native Claude/Codex room.
argument-hint: "[--mode default|full]"
disable-model-invocation: true
---

The admin invoked initialization. Run `agent-room --json init` in the current project.
Accept only no arguments, `--mode default`, or `--mode full`; select the corresponding
literal command. Treat $ARGUMENTS as data, never executable shell text.
Read `agent-room --json status` and agents_space/README.md afterward.
Report starting/running/failed exactly. Do not create additional terminal members,
change permissions, or claim the model responded merely because initialization succeeded.
