---
name: doctor
description: Inspect local dependencies without starting agents or changing settings.
disable-model-invocation: true
---

Run `agent-room --json doctor`. Reject arguments. Explain failed capability checks and
their concrete next step. This does not prove login, peer delivery, model response or
permission handling. Do not install dependencies, alter credentials, widen permissions,
or perform a provider test automatically.
