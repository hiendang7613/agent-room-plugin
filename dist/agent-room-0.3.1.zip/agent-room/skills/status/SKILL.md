---
name: status
description: Summarize members, advisory attention, open work and pending requests.
disable-model-invocation: true
---

Read `agent-room --json status`. Reject arguments. Give a concise Vietnamese summary of
current mode, actual supervisor liveness, member errors, unfinished tasks/next steps,
questions and approvals waiting for admin. A saved running state with no live supervisor
is stale, not healthy. Native turn completion is not task completion. Do not start workers,
repair configuration or make provider calls as part of status.

Use task.review_status, latest_attempt, missing_evidence, last_progress and unprocessed_messages
to identify stale reviews and incomplete work. A completed native attempt or processed ACK
does not mean acceptance passed. Missing native output/turn IDs remain unknown. When recovery
matters, read `agent-room task context TASK_ID` and report its checkpoint_reconcile reasons.

Use `attention.by_member` to summarize current work each member may want to inspect.
Present it as optional attention, with any stated blockers and links to current records.
Members choose whether and when to act within existing authority. A pending review points to
the reviewer; approved peer work awaiting completion points to main. Questions and tentative
ideas remain welcome in ordinary conversation. Reading attention does not send reminders,
acknowledge messages, create tasks or start native turns.
